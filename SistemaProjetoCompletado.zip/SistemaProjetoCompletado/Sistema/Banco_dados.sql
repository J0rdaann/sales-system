CREATE DATABASE House_Tech;

USE House_Tech;


CREATE TABLE tb_cliente (
    idCliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),    
    celular VARCHAR(30)
);

CREATE TABLE tb_fornecedor (
    idFornecedor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(200),
    celular VARCHAR(30),
    endereco VARCHAR(100),
    cidade VARCHAR(100),
    estado CHAR(5)
);

CREATE TABLE tb_funcionario (
    idFuncionario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cpf VARCHAR(20),
    email VARCHAR(200),
    senha VARCHAR(20),
    NivelAcesso VARCHAR(20),
    cargo VARCHAR(100),
    celular VARCHAR(30),
    endereco VARCHAR(255),
    cidade VARCHAR(20),
    estado VARCHAR(20)
);

CREATE TABLE tb_produto (
    idProduto INT AUTO_INCREMENT PRIMARY KEY,
    idFornecedor INT,
    MarcaProduto varchar(100),
    TipoProduto varchar(50),
    preco DECIMAL(10 , 2),
    qtd_estoque INT,
    FOREIGN KEY (idFornecedor)
        REFERENCES tb_fornecedor (idFornecedor)
);

CREATE TABLE tb_venda (
    idVenda INT AUTO_INCREMENT PRIMARY KEY,
    idCliente INT,
    data_venda DATETIME,
    total_venda DECIMAL(10 , 2 ),
    observacoes TEXT,
    FOREIGN KEY (idCliente)
        REFERENCES tb_cliente (idCliente)
);

CREATE TABLE tb_itensVenda (
    idItensVenda INT AUTO_INCREMENT PRIMARY KEY,
    idVenda INT,
    idProduto INT,
    qtd INT,
    subtotal DECIMAL(10 , 2),
    MarcaProduto varchar(100),
    TipoProduto varchar(50),
    FOREIGN KEY (idVenda)
        REFERENCES tb_venda (idVenda),
    FOREIGN KEY (idProduto)
        REFERENCES tb_produto (idProduto)
);
 
insert into 
	tb_funcionario (idFuncionario, nome, cpf, email, senha, cargo, NivelAcesso, celular, endereco, cidade, estado)
values
    (1, 'Jordan', '021.424.724-42', 'jordandsadsa@gmail.com', 12345, 'Vendedor', 'Usuario', '(75) 9 7453-5664', 'Rua Copa do Mundo', 'Paulo Afonso', 'BA'),
	(2, 'Erick', '322.172.962-22', 'erick@hotmail.com', 12345, 'Vendedor', 'Usuario','(71) 9 3469-2125', 'Rua Polo Norte', 'Paulo Afonso', 'BA'),
    (3, 'Denise', '912.263.563-53', 'pedro@gmail.com', 12345, 'Gerente', 'Usuario', '(75) 9 1355-4588', 'Rua Hexa do Brasil', 'Paulo Afonso', 'BA');
     
insert into 
	tb_cliente (idCliente, nome, celular)
values
    (1, 'Erick Barros', '(75) 9 1234-4321'),
    (2, 'Monique Soares', '(75) 9 5345-6435'),
    (3, 'Carla Caorline', '(71) 9 1345-7776');
			
insert into 
	tb_fornecedor (idFornecedor, nome, email, celular, endereco, cidade, estado)
values
	(1, 'Microsoft', 'microsoft@gmail.com', '(61) 9 1249-0433', 'Rua Peixoto','Paulo Afonso', 'BA'),
    (2, 'Luciano', 'luciano@gmail.com', '(75) 9 9865-7546', 'Rua Floriano','Paulo Afonso', 'BA'),
    (3, 'Sony', 'sony@gmail.com', '(36) 9 7657-1133', 'Rua da Aurora','Paulo Afonso', 'BA');
			
insert into 
	tb_produto (idProduto, IdFornecedor, MarcaProduto, TipoProduto, preco, qtd_estoque)
values
	(1, 1, 'HyperX','Teclado', 130, 30),
	(2, 2, 'Xzone', 'Mouse', 97.50, 20),
	(3, 3, 'Capinha de Celular','Iphone', 55, 10);
            
insert into 
	tb_venda (idVenda, idCliente, data_venda, total_venda, observacoes)
values
	(1, 1, 20221106, 390, 'sem'),
    (2, 2, 20221106, 97.50, 'Sem observações'),
    (3, 3, 20221106, 55, 'Sem observações');
			
insert into 
	tb_itensVenda (idItensVenda, IdVenda, idProduto, qtd, subtotal, MarcaProduto, TipoProduto)
values
	(1, 1, 1, 3, 130, 'HyperX', 'Teclado'),
    (2, 1, 1, 3, 130, 'Xzone', 'Mouse'),
    (3, 1, 1, 3, 130, 'Capinha de Celular', 'Iphone');   
    
    