package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.Fornecedor;

public class FornecedorDao {

    private Connection con;

    public FornecedorDao() {
        this.con = new ConnectionFactory().getConnection();
    }

    // Método cadastrar fornecedor
    public void cadastrarFornecedor(Fornecedor obj) {

        try {

            // 1 - criando comando sql
            String sql = "insert into tb_fornecedor(nome, email, celular, endereco, cidade, estado)"
                    + "values(?,?,?,?,?,?)";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getEmail());
            stmt.setString(3, obj.getCelular());
            stmt.setNString(4, obj.getEndereco());
            stmt.setString(5, obj.getCidade());
            stmt.setString(6, obj.getEstado());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Fornecedor cadastrado com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método alterar fornecedor
    public void alterarFornecedor(Fornecedor obj) {

        try {

            // 1 - criando comando sql
            String sql = "update tb_fornecedor set nome=?, email=?, celular=?"
                    + "endereco=?, cidade=?, estado=? where idFornecedor=?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getEmail());
            stmt.setString(3, obj.getCelular());
            stmt.setNString(4, obj.getEndereco());
            stmt.setString(5, obj.getCidade());
            stmt.setString(6, obj.getEstado());
            
            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Informações alteradas com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método excluir fornecedor
    public void excluirFornecedor(Fornecedor obj) {

        try {

            // 1 - criando comando sql
            String sql = "delete from tb_fornecedor where idFornecedor = ?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getIdFornecedor());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Fornecedor excluído com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método listar fornecedor
    public List<Fornecedor> listarFornecedor() {
        try {

            List<Fornecedor> lista = new ArrayList<>();

            String sql = "select * from tb_fornecedor";

            PreparedStatement stmt = con.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Fornecedor obj = new Fornecedor();

                obj.setIdFornecedor(rs.getInt("idFornecedor"));
                obj.setNome(rs.getString("nome"));
                obj.setEmail(rs.getString("email"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método pesquisar fornecedor
    public List<Fornecedor> pesquisarFornecedor(String nome) {

        try {

            List<Fornecedor> lista = new ArrayList<>();

            String sql = "select * from tb_fornecedor where nome like ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Fornecedor obj = new Fornecedor();

                obj.setIdFornecedor(rs.getInt("idFornecedor"));
                obj.setNome(rs.getString("nome"));
                obj.setEmail(rs.getString("email"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    public Fornecedor consultaNome(String nome) {

        try {

            String sql = "select * from tb_fornecedor where nome = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            
            ResultSet rs = stmt.executeQuery();

            Fornecedor obj = new Fornecedor();

            if (rs.next()) {

                obj.setIdFornecedor(rs.getInt("idFornecedor"));
                obj.setNome(rs.getString("nome"));
                obj.setEmail(rs.getString("email"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));
            }

            return obj;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Fornecedor não encontrado!");
            return null;
        }
    }
}
