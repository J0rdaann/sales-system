package br.com.projeto.model;

public class Cliente extends Pessoa {
    private int idCliente;
    private int numero;
	
    public int getIdCliente() {
	return idCliente;
    }
	
    public void setIdCliente(int idCliente) {
	this.idCliente = idCliente;
    }

    public int getNumero() {
	return numero;
    }

    public void setNumero(int numero) {
	this.numero = numero;
    }
}
