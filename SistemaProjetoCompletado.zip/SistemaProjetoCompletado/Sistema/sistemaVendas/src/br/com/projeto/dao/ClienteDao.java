package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.Cliente;

public class ClienteDao {

    private final Connection con;

    public ClienteDao() {

        this.con = (Connection) new ConnectionFactory().getConnection();
    }

    //  Cadastrar cliente
    public void cadastrarCliente(Cliente obj) {

        try {

            // 1 - criando comando sql
            String sql = "insert into tb_cliente(nome, celular) "
                    + "values(?,?)";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getCelular());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método alterar cliente
    public void alterarCliente(Cliente obj) {

        try {

            // 1 - criando comando sql
            String sql = "update tb_cliente set nome=?, celular=?,"
                    + "where idCliente=?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getCelular());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Informações alteradas com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método excluir cliente
    public void excluirCliente(Cliente obj) {

        try {

            // 1 - criando comando sql
            String sql = "delete from tb_cliente where idCliente = ?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getIdCliente());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Cliente excluído com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método listar cliente
    public List<Cliente> listarCliente() {

        try {

            List<Cliente> lista = new ArrayList<>();

            String sql = "select * from tb_cliente";

            PreparedStatement stmt = con.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Cliente obj = new Cliente();

                obj.setIdCliente(rs.getInt("idCliente"));
                obj.setNome(rs.getString("nome"));
                obj.setCelular(rs.getString("celular"));

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método pesquisar cliente
    public List<Cliente> pesquisarCliente(String nome) {
        try {

            List<Cliente> lista = new ArrayList<>();

            String sql = "select * from tb_cliente where nome like ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Cliente obj = new Cliente();

                obj.setIdCliente(rs.getInt("idCliente"));
                obj.setNome(rs.getString("nome"));
                obj.setCelular(rs.getString("celular"));
       
                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    public Cliente consultaNome(String nome) {

        try {

            String sql = "select * from tb_cliente where nome = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();

            Cliente obj = new Cliente();
            if (rs.next()) {

                obj.setIdCliente(rs.getInt("idCliente"));
                obj.setNome(rs.getString("nome"));
                obj.setCelular(rs.getString("celular"));
      
            }

            return obj;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Cliente não encontrado!");
            return null;
        }
    }

}
