package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.Funcionario;
import br.com.projeto.view.JanLogin;
import br.com.projeto.view.JanMenu;

public class FuncionarioDao {

    private Connection con;

    public FuncionarioDao() {
        this.con = new ConnectionFactory().getConnection();
    }

    // Método cadastrar funcionário
    public void cadastrarFuncionario(Funcionario obj) {

        try {

            // 1 - criando comando sql
            String sql = "insert into tb_funcionario(nome, cpf, email, senha, cargo, NivelAcesso, celular, endereco, cidade, estado) "
                    + "values(?,?,?,?,?,?,?,?,?,?)";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getCpf());
            stmt.setString(3, obj.getEmail());
            stmt.setString(4, obj.getSenha());
            stmt.setString(5, obj.getCargo());
            stmt.setString(6, obj.getNivelAcesso());
            stmt.setString(7, obj.getCelular());
            stmt.setString(8, obj.getEndereco());
            stmt.setString(9, obj.getCidade());
            stmt.setString(10, obj.getEstado());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Funcionário cadastrado com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método alterar funcionário
    public void alterarFuncionario(Funcionario obj) {

        try {

            // 1 - criando comando sql
            String sql = "update tb_funcionario set nome=?, cpf=?, email=?, senha=?, cargo=?, NivelAcesso=?. celular=?"
                    + "endereco=?, cidade=?, estado=? where idFuncionario=?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getCpf());
            stmt.setString(3, obj.getEmail());
            stmt.setString(4, obj.getSenha());
            stmt.setString(5, obj.getCargo());
            stmt.setString(6, obj.getNivelAcesso());
            stmt.setString(7, obj.getCelular());
            stmt.setString(8, obj.getEndereco());
            stmt.setString(9, obj.getCidade());
            stmt.setString(10, obj.getEstado());
            
            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Informações alteradas com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método excluir funcionario
    public void excluirFuncionario(Funcionario obj) {

        try {

            // 1 - criando comando sql
            String sql = "delete from tb_funcionario where idFuncionario = ?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getIdFuncionario());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Funcionário excluído com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método listar funcionário
    public List<Funcionario> listarFuncionario() {
        try {

            List<Funcionario> lista = new ArrayList<>();
            String sql = "select * from tb_funcionario";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Funcionario obj = new Funcionario();

                obj.setIdFuncionario(rs.getInt("idFuncionario"));
                obj.setNome(rs.getString("nome"));
                obj.setCpf(rs.getString("cpf"));
                obj.setEmail(rs.getString("email"));
                obj.setSenha(rs.getString("senha"));
                obj.setCargo(rs.getString("cargo"));
                obj.setNivelAcesso(rs.getString("NivelAcesso"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método pesquisar funcionário
    public List<Funcionario> pesquisarFuncionario(String nome) {

        try {

            List<Funcionario> lista = new ArrayList<>();

            String sql = "select * from tb_funcionario where nome like ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Funcionario obj = new Funcionario();

                obj.setIdFuncionario(rs.getInt("idFuncionario"));
                obj.setNome(rs.getString("nome"));
                obj.setCpf(rs.getString("cpf"));
                obj.setEmail(rs.getString("email"));
                obj.setSenha(rs.getString("senha"));
                obj.setCargo(rs.getString("cargo"));
                obj.setNivelAcesso(rs.getString("NivelAcesso"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    public Funcionario consultaNome(String nome) {

        try {

            String sql = "select * from tb_funcionario where nome = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();

            Funcionario obj = new Funcionario();
            if (rs.next()) {

                obj.setIdFuncionario(rs.getInt("idFuncionario"));
                obj.setNome(rs.getString("nome"));
                obj.setCpf(rs.getString("cpf"));
                obj.setEmail(rs.getString("email"));
                obj.setSenha(rs.getString("senha"));
                obj.setCargo(rs.getString("cargo"));
                obj.setNivelAcesso(rs.getString("NivelAcesso"));
                obj.setCelular(rs.getString("celular"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setEstado(rs.getString("estado"));
            }

            return obj;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Funcionário não encontrado!");
            return null;
        }
    }

    // efetuar login
    public void efetuarLogin(String usuario, String senha) {

        try {

            // 1 passo - sql
            String sql = "select * from tb_funcionario where nome = ? and senha = ?";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, usuario);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                if (rs.getString("NivelAcesso").equals("Administrador")) {

                    JOptionPane.showMessageDialog(null, "Seja bem vindo ao sistema!");

                    JanMenu tela = new JanMenu();
                    tela.usuarioLogado = rs.getString("nome");
                    tela.setVisible(true);

                } else if (rs.getString("NivelAcesso").equals("Usuario")) {

                    JOptionPane.showMessageDialog(null, "Seja bem vindo ao sistema!");

                    JanMenu tela = new JanMenu();
                    tela.usuarioLogado = rs.getString("nome");
                    tela.setVisible(true);

                }

            } else {

                JOptionPane.showMessageDialog(null, "Dados incorretos!");
                new JanLogin().setVisible(true);
            }

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }
}
