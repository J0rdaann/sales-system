package br.com.projeto.dao;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.Fornecedor;
import br.com.projeto.model.Produto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class ProdutoDao {

    private final Connection con;

    public ProdutoDao() {

        this.con = (Connection) new ConnectionFactory().getConnection();
    }

    // método cadastrar produto
    public void cadastrarProduto(Produto obj) {

        try {

            String sql = "insert into tb_produto (idFornecedor, MarcaProduto,  TipoProduto, preco, qtd_estoque) values (?,?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getFornecedor().getIdFornecedor());
            stmt.setString(2, obj.getMarcaProduto());
            stmt.setString(3, obj.getTipoProduto());
            stmt.setDouble(4, obj.getPreco());
            stmt.setInt(5, obj.getQtd_estoque());
            

            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso!");

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // método alterar produto
    public void alterarProduto(Produto obj) {

        try {

            String sql = "update tb_produto set idFornecedor=?, MarcaProduto=?, preco=?, qtd_estoque=?, TipoProduto=? where idProduto=?";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getFornecedor().getIdFornecedor());
            stmt.setString(2, obj.getMarcaProduto());
            stmt.setString(3, obj.getTipoProduto());
            stmt.setDouble(4, obj.getPreco());
            stmt.setInt(5, obj.getQtd_estoque());

            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Informações alteradas com sucesso!");

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método excluir produto
    public void excluirProduto(Produto obj) {

        try {

            // 1 - criando comando sql
            String sql = "delete from tb_produto where idProduto=?";

            // 2 - conectando ao banco e organizando o comando sql
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getIdProduto());

            // 3 - executando e fechando o comando sql
            stmt.execute();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Produto excluído com sucesso!");

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // Método listar produto
    public List<Produto> listarProduto() {

        try {

            List<Produto> lista = new ArrayList<>();

            String sql = "select p.idProduto, p.MarcaProduto, p.preco, p.qtd_estoque, p.TipoProduto, f.nome from tb_produto as p "
                    + "inner join tb_fornecedor as f on (p.idFornecedor = f.idFornecedor)";

            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Produto obj = new Produto();
                Fornecedor f = new Fornecedor();

                obj.setIdProduto(rs.getInt("p.idProduto"));
                obj.setMarcaProduto(rs.getString("p.MarcaProduto"));
                obj.setTipoProduto(rs.getString("p.TipoProduto"));
                obj.setPreco(rs.getDouble("p.preco"));
                obj.setQtd_estoque(rs.getInt("p.qtd_estoque"));            
                f.setNome(rs.getString("f.nome"));
                obj.setFornecedor(f);

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método pesquisar produto
    public List<Produto> pesquisarProduto(String nome) {

        try {

            List<Produto> lista = new ArrayList<>();

            String sql = "select p.idProduto, p.MarcaProduto, p.preco, p.qtd_estoque, p.TipoProduto, f.nome from tb_produto as p "
                    + "inner join tb_fornecedor as f on (p.idFornecedor = f.idFornecedor) where p.MarcaProduto like ?";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Produto obj = new Produto();
                Fornecedor f = new Fornecedor();

                obj.setIdProduto(rs.getInt("p.idProduto"));
                obj.setMarcaProduto(rs.getString("p.MarcaProduto"));
                obj.setTipoProduto(rs.getString("p.TipoProduto"));
                obj.setPreco(rs.getDouble("p.preco"));
                obj.setQtd_estoque(rs.getInt("p.qtd_estoque"));            
                f.setNome(rs.getString("f.nome"));
                obj.setFornecedor(f);

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método consultar produto
    public Produto consultaProduto(String nome) {

        try {

            String sql = "select p.idProduto, p.MarcaProduto, p.preco, p.qtd_estoque, p.TipoProduto, f.nome from tb_produto as p "
                    + "inner join tb_fornecedor as f on (p.idFornecedor = f.idFornecedor) where p.MarcaProduto = ?";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();
            Produto obj = new Produto();
            Fornecedor f = new Fornecedor();

            if (rs.next()) {

                obj.setIdProduto(rs.getInt("p.idProduto"));
                obj.setMarcaProduto(rs.getString("p.MarcaProduto"));
                obj.setTipoProduto(rs.getString("p.TipoProduto"));
                obj.setPreco(rs.getDouble("p.preco"));
                obj.setQtd_estoque(rs.getInt("p.qtd_estoque"));            
                f.setNome(rs.getString("f.nome"));
                obj.setFornecedor(f);
            }

            return obj;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // Método consultar produto
    public Produto consultaProdutoCodigo(int idProduto) {

        try {

            String sql = "select * from tb_produto where idProduto = ?";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idProduto);

            ResultSet rs = stmt.executeQuery();
            Produto obj = new Produto();

            if (rs.next()) {
                
                obj.setIdProduto(rs.getInt("p.idProduto"));
                obj.setMarcaProduto(rs.getString("p.MarcaProduto"));
                obj.setTipoProduto(rs.getString("p.TipoProduto"));
                obj.setPreco(rs.getDouble("p.preco"));
                obj.setQtd_estoque(rs.getInt("p.qtd_estoque"));            

            }

            return obj;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // método baixa de estoque
    public void baixaEstoque(int id, int qtdNova) {

        try {

            String sql = "update tb_produto set qtd_estoque = ? where idProduto = ?";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, qtdNova);
            stmt.setInt(2, id);
            stmt.execute();
            stmt.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // metodo estoque atual
    public int retornaEstoqueAtual(int id) {

        int qtd_estoque = 0;

        try {

            String sql = "select qtd_estoque from tb_produto where idProduto = ?";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                qtd_estoque = (rs.getInt("qtd_estoque"));
            }

            return qtd_estoque;

        } catch (SQLException erro) {

            throw new RuntimeException(erro);
        }
    }

    public void adicionarEstoque(int id, int qtdNova) {

        try {

            String sql = "update tb_produto set qtd_estoque = ? where idProduto = ?";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, qtdNova);
            stmt.setInt(2, id);
            stmt.execute();
            stmt.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }
}
