package br.com.projeto.model;

public class ItensVenda {

    private int idItemVenda;
    private int qtd;
    private double subtotal;
    private String MarcaProduto;
    private String TipoProduto;
    private Venda venda;
    private Produto produto;

    public int getIdItemVenda() {
        return idItemVenda;
    }

    public void setIdItemVenda(int idItemVenda) {
        this.idItemVenda = idItemVenda;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public String getMarcaProduto() {
        return MarcaProduto;
    }

    public void setMarcaProduto(String descricao) {
        this.MarcaProduto = descricao;
    }

    public String getTipoProduto() {
        return TipoProduto;
    }

    public void setTipoProduto(String tipo) {
        this.TipoProduto = tipo;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

}
