package br.com.projeto.dao;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.ItensVenda;
import br.com.projeto.model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Robson, william e andrey.
 */
public class ItensVendaDao {

    private Connection con;

    public ItensVendaDao() {

        this.con = new ConnectionFactory().getConnection();
    }

    //cadastrar intens da venda
    public void cadastrarItem(ItensVenda obj) {

        try {

            String sql = "insert into tb_itensVenda(idVenda, idProduto, qtd, subtotal, MarcaProduto, TipoProduto) values (?,?,?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getVenda().getIdVenda());
            stmt.setInt(2, obj.getProduto().getIdProduto());
            stmt.setInt(3, obj.getQtd());
            stmt.setDouble(4, obj.getSubtotal());
            stmt.setString(5, obj.getMarcaProduto());
            stmt.setString(6, obj.getTipoProduto());

            stmt.execute();
            stmt.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }

    // método que lista detalhes dos itens de uma venda
    public List<ItensVenda> listarItensPorVenda(int idVenda) {

        try {

            List<ItensVenda> lista = new ArrayList<>();

            String sql = "select p.MarcaProduto, i.qtd, i.TipoProduto, p.preco, i.subtotal from tb_itensvenda as i "
                    + "inner join tb_produto as p on (i.idProduto = p.idProduto) where i.idVenda = ?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idVenda);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                ItensVenda item = new ItensVenda();
                Produto prod = new Produto();

                item.setQtd(rs.getInt("i.qtd"));
                item.setMarcaProduto(rs.getString("i.MarcaProduto"));
                item.setTipoProduto(rs.getString("i.TipoProduto"));
                prod.setPreco(rs.getDouble("p.preco"));
                item.setSubtotal(rs.getDouble("i.subtotal"));
                item.setProduto(prod);

                lista.add(item);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }
}
