package br.com.projeto.view;

import br.com.projeto.dao.FuncionarioDao;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;


public class JanLogin extends javax.swing.JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    public JanLogin() {
		setType(Type.UTILITY);
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        txtsenha = new javax.swing.JPasswordField();
        jLabel17 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        btnentrar = new javax.swing.JButton();
        btnentrar.setForeground(Color.BLACK);
        btnentrar.setBackground(new Color(0, 255, 0));
        btnsair = new javax.swing.JButton();
        btnsair.setBackground(Color.RED);
        btnsair.setForeground(Color.BLACK);
        
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Sistema de Vendas");

        txtsenha.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        jLabel17.setFont(new Font("Segoe UI", Font.BOLD, 16)); // NOI18N
        jLabel17.setText("Senha:");

        jLabel4.setFont(new Font("Segoe UI", Font.BOLD, 16)); // NOI18N
        jLabel4.setText("Usuario:");

        txtusuario.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtusuarioActionPerformed(evt);
            }
        });

        btnentrar.setFont(new Font("Segoe UI", Font.BOLD, 16)); // NOI18N
        btnentrar.setText("ENTRAR");
        btnentrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnentrarActionPerformed(evt);
            }
        });

        btnsair.setFont(new Font("Segoe UI", Font.BOLD, 16)); // NOI18N
        btnsair.setText("SAIR");
        btnsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsairActionPerformed(evt);
            }
        });
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 0, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(Alignment.TRAILING, layout.createSequentialGroup()
        			.addGap(79)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(11)
        					.addComponent(jLabel17, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        			.addGap(18)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(txtsenha, GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(btnentrar, GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
        					.addGap(41)
        					.addComponent(btnsair, GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
        					.addGap(10))
        				.addComponent(txtusuario, GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE))
        			.addGap(142))
        		.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 529, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(panel, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
        			.addGap(38)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel4)
        				.addComponent(txtusuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(18)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel17)
        				.addComponent(txtsenha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(32)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(btnentrar)
        				.addComponent(btnsair))
        			.addContainerGap(50, Short.MAX_VALUE))
        );
        panel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Login do Sistema:");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 33));
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setBounds(34, 0, 495, 85);
        panel.add(lblNewLabel);
        layout.linkSize(SwingConstants.VERTICAL, new Component[] {btnentrar, btnsair});
        getContentPane().setLayout(layout);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtusuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtusuarioActionPerformed

    @SuppressWarnings("deprecation")
	private void btnentrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnentrarActionPerformed

        try {

            String usuario, senha;
            usuario = txtusuario.getText();
            senha = txtsenha.getText();

            FuncionarioDao dao = new FuncionarioDao();

            dao.efetuarLogin(usuario, senha);
            this.dispose();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }
    }//GEN-LAST:event_btnentrarActionPerformed

    private void btnsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsairActionPerformed
        
        int op;

        op = JOptionPane.showConfirmDialog(null, "Você deseja sair?");

        if (op == 0) {

            System.exit(0);
        }
    }//GEN-LAST:event_btnsairActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JanLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JanLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JanLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JanLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JanLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnentrar;
    private javax.swing.JButton btnsair;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField txtusuario;
    private javax.swing.JPasswordField txtsenha;
}
