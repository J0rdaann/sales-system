package br.com.projeto.dao;

import br.com.projeto.jbdc.ConnectionFactory;
import br.com.projeto.model.Cliente;
import br.com.projeto.model.Venda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class VendaDao {

    private Connection con;

    public VendaDao() {

        this.con = new ConnectionFactory().getConnection();
    }

    //cadastrar venda
    public void cadastrarVenda(Venda obj) {

        try {

            String sql = "insert into tb_venda(idCliente, data_venda, total_venda, observacoes) values (?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, obj.getCliente().getIdCliente());
            stmt.setString(2, obj.getData_venda());
            stmt.setDouble(3, obj.getTotal_venda());
            stmt.setString(4, obj.getObservacoes());

            stmt.execute();
            stmt.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
        }

    }

    // retorna ultima venda
    public int retornaUltimaVenda() {

        try {

            int idvenda = 0;

            String sql = "select max(idVenda) idVenda from tb_venda";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Venda p = new Venda();

                p.setIdVenda(rs.getInt("idVenda"));

                idvenda = p.getIdVenda();
            }

            return idvenda;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // método listar vendas por data
    public List<Venda> listarVendasPeriodo(LocalDate dataInicio, LocalDate dataFim) {

        try {

            List<Venda> lista = new ArrayList<>();

            String sql = "select v.idVenda, date_format(v.data_venda, '%d/%m/%Y') as data_formatada, c.nome, v.total_venda, v.observacoes from tb_venda as v "
                    + "inner join tb_cliente as c on (v.idCliente = c.idCliente) where v.data_venda BETWEEN ? AND ? ORDER BY v.idVenda DESC";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, dataInicio.toString());
            stmt.setString(2, dataFim.toString());

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Venda obj = new Venda();
                Cliente c = new Cliente();

                obj.setIdVenda(rs.getInt("v.idVenda"));
                obj.setData_venda(rs.getString("data_formatada"));
                c.setNome(rs.getString("c.nome"));
                obj.setTotal_venda(rs.getDouble("v.total_venda"));
                obj.setObservacoes(rs.getString("v.observacoes"));

                obj.setCliente(c);

                lista.add(obj);
            }

            return lista;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Erro: " + erro);
            return null;
        }
    }

    // retorna total da venda por data
    public double retornaTotalVendaPorData(LocalDate data_venda) {

        try {

            double totalVenda = 0;

            String sql = "select sum(total_venda) as total from tb_venda where data_venda = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, data_venda.toString());

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                totalVenda = rs.getDouble("total");
            }

            return totalVenda;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
