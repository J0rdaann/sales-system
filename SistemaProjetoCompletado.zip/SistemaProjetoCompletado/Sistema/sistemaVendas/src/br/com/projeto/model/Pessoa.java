package br.com.projeto.model;

public class Pessoa {
    
    private String nome;
    private String rg;
    private String cpf;
    private String email;
    private String celular;
    
    public String getNome() {
	return nome;
    }

    public void setNome(String nome) {
	this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getCpf() {
	return cpf;
    }

    public void setCpf(String cpf) {
	this.cpf = cpf;
    }

    public String getRg() {
	return rg;
    }

    public void setRg(String rg) {
	this.rg = rg;
    }

    public String getCelular() {
	return celular;
    }

    public void setCelular(String celular) {
	this.celular = celular;
    }
}
