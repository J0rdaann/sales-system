package br.com.projeto.jbdc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionFactory {
	
	static String url = "jdbc:mysql://127.0.0.1:3306/House_Tech";
	static String usuario = "root";
	static String senha = "";
	static Connection con;
	
    public Connection getConnection() {
		
	try {
	
            return DriverManager.getConnection(url, usuario, senha);

	} catch (SQLException erro) {
		    
            throw new RuntimeException(erro);
	}	
    }
}
